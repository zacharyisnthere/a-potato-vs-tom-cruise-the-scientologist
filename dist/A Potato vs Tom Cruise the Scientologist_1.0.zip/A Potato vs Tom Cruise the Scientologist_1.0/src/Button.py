#!/home/zachary/Documents/Repos/apotatovstomcruisethescientologist/venv/bin/python

import pygame

class Button():
    def __init__(self, image, behavior=None, hover_behavior={'display': None, 'sfx': None}, select_behavior={'display': None, 'sfx': None}):
        super().__init__(groups)
        

    
    def delete(self):
        self.kill()    